import React from 'react';
import './AboutUs.css';
//import logoncc from 'C:/Users/91859/OneDrive/Documents/GitHub/NCC-website/ncc/src/images/logoncc.png';
//import NCCTimeline from './NCCTimeline';

const AboutUs = () => {
  return (
    <div className="about-us">
      <h1>helllo about</h1>
    </div>
  );
};

export default AboutUs;
