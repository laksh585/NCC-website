import React from 'react';
import { Routes, Route, BrowserRouter } from 'react-router-dom';
import Home from './pages/Home';
import About from './pages/About';
import NCC from './pages/NCC';
import Navbar from './components/Navbar/Navbar'; // Import Navbar

function App() {
  return (
    <BrowserRouter> {/* Wrap everything in BrowserRouter */}
      <div>
        <Navbar /> {/* Render the Navbar */}
        <Routes> {/* Define your routing */}
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/ncc" element={<NCC />} /> 
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;