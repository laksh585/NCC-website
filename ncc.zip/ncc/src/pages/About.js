import React from 'react';
import AboutUs from '../components/About/AboutUs'; 

function About() {
  return (
    <div>
      <AboutUs/> 
    </div>
  );
}

export default About;