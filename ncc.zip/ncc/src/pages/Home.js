import React from 'react';
import Navbar from '../components/Navbar/Navbar';
import Banner from '../components/Banner/Banner';
import Desk from '../components/Desk/Desk';
import Footer from '../components/Footer/Footer';
function Home() {
  return (
    <div>
        <Navbar />
        <Banner />
        <Desk />
        <Footer />
    </div>
  );
}

export default Home;
